package com.example.cafeproject;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.util.List;

public class guestcontroller {
    @FXML
    private GridPane menuGrid;


    public void initialize() {

        List<MENUITEM> menuItems = MENUITEM.getAllMenuItems();

        int rowIndex = 0;
        int columnIndex = 0;

        for (MENUITEM menuItem : menuItems) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("itemcard.fxml"));
                AnchorPane anchorPane = loader.load();
                itemcardcontroller controller = loader.getController();
                controller.setMenuItem(menuItem);

                GridPane.setRowIndex(anchorPane, rowIndex);
                GridPane.setColumnIndex(anchorPane, columnIndex);

                menuGrid.getChildren().add(anchorPane);

                columnIndex++;
                if (columnIndex == 3) {
                    columnIndex = 0;
                    rowIndex++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
