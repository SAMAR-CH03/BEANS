package com.example.cafeproject;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CONN {
    private static final String URL = "jdbc:oracle:thin:@DILUC:1521:xe";
    private static final String USERNAME = "CafeManagementDB";
    private static final String PASSWORD = "java";
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
                throw new SQLException("Unable to connect to the database");
            }
        }
        return connection;
    }
}











