package com.example.cafeproject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.SQLException;
import javax.imageio.ImageIO;

import javafx.embed.swing.SwingFXUtils;
import javafx.scene.image.Image;

public class ImageUtils {
    public static byte[] convertImageToByteArray(Image image) throws SQLException {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            String format = "png";
            if (image.getUrl().toLowerCase().endsWith(".jpg") || image.getUrl().toLowerCase().endsWith(".jpeg")) {
                format = "jpg";
            }
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), format, outputStream);
            return outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            throw new SQLException("Error converting image to byte array.");
        }
    }

    public static Image convertByteArrayToImage(byte[] imageData) throws IOException {
        try (ByteArrayInputStream inputStream = new ByteArrayInputStream(imageData)) {
            return new Image(inputStream);
        }
    }
}
