package com.example.cafeproject;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MENUITEM {
    private int itemId;
    private String name;
    private String description;
    private double price;
    private String status;
    private byte[] imageBytes;


    public MENUITEM(int itemId, String name, String description, double price, String status, byte[] imageBytes) {
        this.itemId = itemId;
        this.name = name;
        this.description = description;
        this.price = price;
        this.status = status;
        this.imageBytes=imageBytes;
    }
    public MENUITEM(int itemId, String name, Double price, byte[] imageBytes){
        this.itemId=itemId;
        this.name=name;
        this.price=price;
        this.imageBytes=imageBytes;
    }

    public MENUITEM() {
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public byte[] getImageBytes() {
        return imageBytes;
    }

    public void setImageBytes(byte[] imageBytes) {
        this.imageBytes = imageBytes;
    }

    public void addItem(int itemId, String name, String description, double price, String status, byte[] imageBytes) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("INSERT INTO MENUITEMS (itemId, name, description, price, status, MENUIMGDATA) VALUES (?, ?, ?, ?, ?, ?)");
            stmt.setInt(1, itemId);
            stmt.setString(2, name);
            stmt.setString(3, description);
            stmt.setDouble(4, price);
            stmt.setString(5, status);
            stmt.setBytes(6, imageBytes);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("A new menu item was inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateItem(int itemId, String name, String description, double price, String status, byte[] imageBytes) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("UPDATE MENUITEMS SET name = ?, description = ?, price = ?, status = ?, MENUIMGDATA=? WHERE itemId = ?");
            stmt.setString(1, name);
            stmt.setString(2, description);
            stmt.setDouble(3, price);
            stmt.setString(4, status);
            stmt.setInt(5, itemId);
            stmt.setBytes(6, imageBytes);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Menu item was updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteItem(int itemId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("DELETE FROM MENUITEMS WHERE itemId = ?");
            stmt.setInt(1, itemId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Menu item was deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static List<MENUITEM> getAllMenuItems() {
        List<MENUITEM> menuItems = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM MENUITEMS");
            rs = stmt.executeQuery();
            while (rs.next()) {
                int itemId = rs.getInt("itemId");
                String name = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                String status = rs.getString("status");
                byte[] imageBytes= rs.getBytes("MENUIMGDATA");
                MENUITEM menuItem = new MENUITEM(itemId, name, description, price, status, imageBytes);
                menuItems.add(menuItem);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return menuItems;
    }
    public static List<MENUITEM> getAllItems() {
        List<MENUITEM> itemList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM MENUITEMS");
            rs = stmt.executeQuery();
            while (rs.next()) {
                int itemId = rs.getInt("itemId");
                String name = rs.getString("name");
                String desc = rs.getString("description");
                double price = rs.getDouble("price");
                String status = rs.getString("status");
                byte[] imageBytes= rs.getBytes("MENUIMGDATA");
                MENUITEM item = new MENUITEM(itemId, name, desc, price, status, imageBytes);
                itemList.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return itemList;
    }
}


