package com.example.cafeproject;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.ByteArrayInputStream;
import java.util.Objects;

public class itemcardcontroller {

    @FXML
    private Label cardname;

    @FXML
    private ImageView cardimg;

    @FXML
    private Label cardprice;

    public void setMenuItem(MENUITEM menuItem) {
        cardname.setText(menuItem.getName());
        cardprice.setText(String.valueOf(menuItem.getPrice()));

        byte[] imageBytes = menuItem.getImageBytes();
        if (imageBytes != null) {
            Image image = new Image(new ByteArrayInputStream(imageBytes));
            cardimg.setImage(image);
        } else {
            Image defaultImage = new Image(getClass().getResourceAsStream("/BEANS LOGO.png"));


            cardimg.setImage(defaultImage);
        }
    }

}
