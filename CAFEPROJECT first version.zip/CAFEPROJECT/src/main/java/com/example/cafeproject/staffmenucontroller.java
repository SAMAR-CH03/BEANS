package com.example.cafeproject;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import com.almasb.fxgl.inventory.ItemData;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.ByteArrayInputStream;
import java.io.File;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

public class staffmenucontroller {
    @FXML
    private TableView<MENUITEM> tableView;

    @FXML
    private TableColumn<MENUITEM, Integer> itemIdColumn;
    @FXML
    private TableColumn<MENUITEM, String> nameColumn;
    @FXML
    private TableColumn<MENUITEM, String> descriptionColumn;
    @FXML
    private TableColumn<MENUITEM, Double> priceColumn;
    @FXML
    private TableColumn<MENUITEM, String> statusColumn;

    @FXML
    private TextField itemIdField;
    @FXML
    private TextField itemNameField;
    @FXML
    private TextArea itemDescriptionField;
    @FXML
    private TextField itemPriceField;
    @FXML
    private RadioButton available;
    @FXML
    private RadioButton unavailable;
    @FXML
    private ToggleGroup statusToggleGroup;
    @FXML
    private ImageView itemimg;

    private ObservableList<MENUITEM> menuItems;
    private MENUITEM menuItem;
    private MENUITEM selectedItem;

    @FXML
    private Button ordersbtn;

    @FXML
    private Button exitbtn;

    @FXML
    private Button inventorybtn;

    @FXML
    private Button menubtn;

    @FXML
    private void initialize() {
        statusToggleGroup = new ToggleGroup();
        if (available != null && unavailable != null) {
            available.setToggleGroup(statusToggleGroup);
            unavailable.setToggleGroup(statusToggleGroup);
        }
        menuItem = new MENUITEM();
        menuItems = FXCollections.observableArrayList();
        tableView.setItems(menuItems);

        itemIdColumn.setCellValueFactory(new PropertyValueFactory<>("itemId"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        List<MENUITEM> itemList = menuItem.getAllItems();
        menuItems.addAll(itemList);
        tableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                selectedItem = newValue;
                itemIdField.setText(String.valueOf(newValue.getItemId()));
                itemNameField.setText(newValue.getName());
                itemDescriptionField.setText(newValue.getDescription());
                itemPriceField.setText(String.valueOf(newValue.getPrice()));
                byte[] imageData = newValue.getImageBytes();
                if (imageData != null && imageData.length > 0) {
                    Image image = new Image(new ByteArrayInputStream(imageData));
                    itemimg.setImage(image);
                } else {
                    itemimg.setImage(null);
                }
                if (newValue.getStatus().equals("Available")) {
                    available.setSelected(true);
                } else {
                    unavailable.setSelected(true);
                }
            }
        });
    }

    @FXML
    private void addItem() throws SQLException {
        int itemId = Integer.parseInt(itemIdField.getText());
        String name = itemNameField.getText();
        String description = itemDescriptionField.getText();
        Image image = itemimg.getImage();
        Blob imageBlob = null;
        byte[] imageData = null;
        if (image != null) {
            imageData = ImageUtils.convertImageToByteArray(image);
        }
        double price = Double.parseDouble(itemPriceField.getText());
        String status = ((RadioButton) statusToggleGroup.getSelectedToggle()).getText();
        menuItem.addItem(itemId, name, description, price, status, imageData);
        refreshTable();
    }

    @FXML
    private void updateItem() throws SQLException {
        int itemId = Integer.parseInt(itemIdField.getText());
        String name = itemNameField.getText();
        String description = itemDescriptionField.getText();
        double price = Double.parseDouble(itemPriceField.getText());
        String status = ((RadioButton) statusToggleGroup.getSelectedToggle()).getText();
        Image image = itemimg.getImage();
        Blob imageBlob = null;
        byte[] imageData = null;
        if (image != null) {
            imageData = ImageUtils.convertImageToByteArray(image);
        }
        menuItem.updateItem(itemId, name, description, price, status, imageData);
        refreshTable();
    }

    @FXML
    private void deleteItem() {
        int itemId = Integer.parseInt(itemIdField.getText());

        menuItem.deleteItem(itemId);
        refreshTable();
    }

    @FXML
    private void clearFields() {
        itemIdField.clear();
        itemNameField.clear();
        itemDescriptionField.clear();
        statusToggleGroup.selectToggle(null);
        itemPriceField.clear();
        itemimg.setImage(null);
    }

    private void refreshTable() {
        menuItems.clear();
        menuItems.addAll(menuItem.getAllItems());
    }
    @FXML
    private void loadImage() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Image File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG Files", "*.png"),
                new FileChooser.ExtensionFilter("JPEG Files", "*.jpg", "*.jpeg")
        );
        File selectedFile = fileChooser.showOpenDialog(null);
        if (selectedFile != null) {
            Image image = new Image(selectedFile.toURI().toString());
            itemimg.setImage(image);
        }
    }
    @FXML
    public void handleButtonAction(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene;
        switch (node.getId()) {
            case "inventorybtn":
                Parent root = FXMLLoader.load(getClass().getResource("staff-menu.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "menubtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu-1.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "ordersbtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu2.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "exitbtn":
                System.exit(0);
                break;
        }
    }


}

