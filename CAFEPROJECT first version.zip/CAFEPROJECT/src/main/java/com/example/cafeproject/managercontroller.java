package com.example.cafeproject;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import java.util.List;
import java.util.ArrayList;

public class managercontroller {
    @FXML
    private TableView<USERS> tableView;
    @FXML
    private TableColumn<USERS, Integer> userIdColumn;
    @FXML
    private TableColumn<USERS, String> usernameColumn;
    @FXML
    private TableColumn<USERS, String> passwordColumn;
    @FXML
    private TableColumn<USERS, String> accountTypeColumn;
    @FXML
    private TableColumn<USERS, String> favecolorColumn;
    @FXML
    private Label useridfield;
    @FXML
    private Label usernamefield;
    @FXML
    private Label passwordfield;
    @FXML
    private ChoiceBox<String> choiceboxtype;
    @FXML
    private TextField useridTextField;
    @FXML
    private TextField usernameTextField;
    @FXML
    private TextField passwordTextField;
    @FXML
    private TextField favecolorTextField;


    private ObservableList<USERS> usersData = FXCollections.observableArrayList();
    private USERS selectedUser;



    @FXML
    private void initialize() {
        ObservableList<String> userTypeOptions = FXCollections.observableArrayList("administrator", "staff");
        choiceboxtype.setItems(userTypeOptions);
        List<USERS> userList = getUsersFromDatabase();
        usersData.addAll(userList);
        userIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        accountTypeColumn.setCellValueFactory(new PropertyValueFactory<>("userType"));
        favecolorColumn.setCellValueFactory(new PropertyValueFactory<>("favouriteColor"));


        tableView.setItems(usersData);

        tableView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                selectedUser = newValue;
                useridTextField.setText(String.valueOf(newValue.getUserId()));
                usernameTextField.setText(newValue.getUsername());
                passwordTextField.setText(newValue.getPassword());
                choiceboxtype.setValue(newValue.getUserType());
                favecolorTextField.setText(newValue.getFavouriteColor());
            }
        });
    }

    private List<USERS> getUsersFromDatabase() {
        return USERS.getAllUsers();
    }
    @FXML
    private void addUser() {
        int userId = Integer.parseInt(useridTextField.getText());
        String username = usernameTextField.getText();
        String password = passwordTextField.getText();
        String userType = choiceboxtype.getValue();
        String favouriteColor = favecolorTextField.getText();

        USERS newUser = new USERS(userId, username, password, userType, favouriteColor);
        newUser.addUser(userId, username, password, userType, favouriteColor);

        usersData.add(newUser);
    }
    @FXML
    private void updateUser() {
        if (selectedUser != null) {
            selectedUser.setUsername(usernameTextField.getText());
            selectedUser.setPassword(passwordTextField.getText());
            selectedUser.setUserType(choiceboxtype.getValue());
            selectedUser.setFavouriteColor(favecolorTextField.getText());
            selectedUser.updateUser(selectedUser.getUsername(), selectedUser.getPassword(), selectedUser.getUserType(), selectedUser.getFavouriteColor());
            tableView.refresh();
        }
    }

    @FXML
    private void deleteUser() {
        if (selectedUser != null) {
            selectedUser.deleteUser(selectedUser.getUsername(), selectedUser.getPassword(), selectedUser.getUserType());
            usersData.remove(selectedUser);
            clearFields();
        }
    }

    @FXML
    private void clearFields() {
        useridTextField.clear();
        usernameTextField.clear();
        passwordTextField.clear();
        choiceboxtype.getSelectionModel().clearSelection();
        favecolorTextField.clear();
        selectedUser = null;
    }

    @FXML
    private void exitApplication() {
        System.exit(0);
    }
}
