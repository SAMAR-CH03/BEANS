package com.example.cafeproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

public class staffmenucontroller1 {
    @FXML
    private Button ordersbtn;

    @FXML
    private Button exitbtn;

    @FXML
    private Button inventorybtn;

    @FXML
    private Button menubtn;
    @FXML
    private AnchorPane menu;
    @FXML
    private GridPane menuGrid;


    public void initialize() {

        List<MENUITEM> menuItems = MENUITEM.getAllMenuItems();

        int rowIndex = 0;
        int columnIndex = 0;

        for (MENUITEM menuItem : menuItems) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("itemcard.fxml"));
                AnchorPane anchorPane = loader.load();
                itemcardcontroller controller = loader.getController();
                controller.setMenuItem(menuItem);

                GridPane.setRowIndex(anchorPane, rowIndex);
                GridPane.setColumnIndex(anchorPane, columnIndex);

                menuGrid.getChildren().add(anchorPane);

                columnIndex++;
                if (columnIndex == 3) {
                    columnIndex = 0;
                    rowIndex++;
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    @FXML
    public void handleButtonAction(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene;
        switch (node.getId()) {
            case "inventorybtn":
                Parent root = FXMLLoader.load(getClass().getResource("staff-menu.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "menubtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu-1.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "ordersbtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu2.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "exitbtn":
                System.exit(0);
                break;
        }
    }
}
