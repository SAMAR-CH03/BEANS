package com.example.cafeproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ORDERITEM {
    private int itemId;
    private int quantity;
    public ORDERITEM(int itemId, int quantity) {
        this.itemId = itemId;
        this.quantity = quantity;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public static void createOrderItem(int orderId, int itemId, int quantity) throws SQLException {
        String insertQuery = "INSERT INTO ORDER_ITEMS (ORDER_ITEM_ID, ORDERID, ITEMID, QUANTITY) VALUES (?,?,?,?)";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement = conn.prepareStatement(insertQuery)) {
            statement.setInt(1, orderId);
            statement.setInt(2, itemId);
            statement.setInt(3, quantity);
            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating order item failed, no rows affected.");
            }
        }
    }
    public static void updateOrderItemQuantity(int orderItemId, int newQuantity) throws SQLException {
        String updateQuery = "UPDATE ORDER_ITEMS SET QUANTITY = ? WHERE ORDER_ITEM_ID = ?";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement = conn.prepareStatement(updateQuery)) {
            statement.setInt(1, newQuantity);
            statement.setInt(2, orderItemId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Updating order item failed, no rows affected.");
            }
        }
    }
    public static void deleteOrderItem(int orderItemId) throws SQLException {
        String deleteQuery = "DELETE FROM ORDER_ITEMS WHERE ORDER_ITEM_ID = ?";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement = conn.prepareStatement(deleteQuery)) {
            statement.setInt(1, orderItemId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Deleting order item failed, no rows affected.");
            }
        }
    }
}
