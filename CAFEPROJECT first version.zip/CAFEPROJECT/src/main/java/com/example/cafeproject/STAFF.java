package com.example.cafeproject;

public class STAFF {
    private int userId;
    private String position;

    public STAFF(int userId, String position) {
        this.userId = userId;
        this.position = position;
    }

    public int getUserId() {
        return userId;
    }

    public String getPosition() {
        return position;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setPosition(String position) {
        this.position = position;
    }

}
