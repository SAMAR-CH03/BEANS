package com.example.cafeproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class staffmenucontroller2 {
    @FXML
    private Button ordersbtn;

    @FXML
    private Button exitbtn;

    @FXML
    private Button inventorybtn;

    @FXML
    private Button menubtn;
    @FXML
    public void handleButtonAction(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        Scene scene;
        switch (node.getId()) {
            case "inventorybtn":
                Parent root = FXMLLoader.load(getClass().getResource("staff-menu.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "menubtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu-1.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "ordersbtn":
                root = FXMLLoader.load(getClass().getResource("staff-menu2.fxml"));
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
                break;
            case "exitbtn":
                System.exit(0);
                break;
        }
    }
}
