package com.example.cafeproject;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.Node;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import javafx.animation.PauseTransition;
import javafx.util.Duration;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

import java.io.IOException;

public class useracccontroller {
    @FXML
    private TextField username;
    @FXML
    private TextField password;
    @FXML
    private TextField favecolor;
    @FXML
    private Label errorLabel;
    @FXML
    private Hyperlink forgotten;




    @FXML
    protected void onloginbuttonclick(ActionEvent event) {
        String U = username.getText();
        String P = password.getText();
        USERS user = new USERS();
        if (user.login(U, P)) {
            String userType = user.getUserType();
            if ("administrator".equals(userType)) {
                redirectToUserAccountsManager(event);
            } else if ("staff".equals(userType)) {
                redirectToStaffMenu(event);
            }
        } else {
            errorLabel.setText("Username and password don't match");
        }
    }

    @FXML
    private void redirectToUserAccountsManager(ActionEvent event) {
        errorLabel.setText("Access granted!");
        PauseTransition pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(e -> {
            try {
                Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                currentStage.close();
                FXMLLoader loader = new FXMLLoader(getClass().getResource("user-accounts-manager1.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException i) {
                i.printStackTrace();
            }
        });
        pause.play();
    }

    @FXML
    private void redirectToStaffMenu(ActionEvent event) {
        errorLabel.setText("Access granted!");
        PauseTransition pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(e -> {
            try {
                Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                currentStage.close();
                FXMLLoader loader = new FXMLLoader(getClass().getResource("staff-menu.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException i) {
                i.printStackTrace();
            }
        });
        pause.play();
    }


    @FXML
    protected void onforgottenclick(ActionEvent event) {
        try {
            Stage currentStage = (Stage) username.getScene().getWindow();
            currentStage.close();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("forgot-password.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    @FXML
    protected void onlogin2buttonclick(ActionEvent event) {
        String U = username.getText();
        String F = favecolor.getText();
        String A = "administrator";
        USERS b = new USERS();
        if (b.login2(U, F, A)) {
            errorLabel.setText("access granted!");
            PauseTransition pause = new PauseTransition(Duration.seconds(2));
            pause.setOnFinished(e -> {
                try {
                    Stage currentStage = (Stage) username.getScene().getWindow();
                    currentStage.close();
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("user-accounts-manager1.fxml"));
                    Parent root = loader.load();
                    Stage stage = new Stage();
                    stage.setScene(new Scene(root));
                    stage.show();
                } catch (IOException i) {
                    i.printStackTrace();
                }
            });
            pause.play();

        } else {
            errorLabel.setText("security question violated");
        }
    }


    @FXML
    protected void onexitclick (ActionEvent event){
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.close();
    }

}
