package com.example.cafeproject;


import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ORDER {
    private static int orderId;
    private int guestId;
    private Date orderDate;
    private String orderstatus;
    private List<ORDERITEM> orderItems;

    public ORDER(int orderId, int guestId, Date orderDate, String orderstatus ) {
        this.orderId = orderId;
        this.guestId = guestId;
        this.orderDate = orderDate;
        this.orderstatus=orderstatus;
        this.orderItems = new ArrayList<>();

    }


    public String getOrderstatus() {
        return orderstatus;
    }

    public void setOrderstatus(String orderstatus) {
        this.orderstatus = orderstatus;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getGuestId() {
        return guestId;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
    public static ORDER createOrder(int guestId, Date orderDate, String orderStatus, List<ORDERITEM> orderItems) throws SQLException {
        String insertOrderQuery = "INSERT INTO ORDERS (ORDERID, GUEST_ID, ORDERDATE, STATUS) VALUES (?,?,?,?)";
        String insertOrderItemQuery = "INSERT INTO ORDER_ITEMS (ORDER_ITEM_ID, ORDERID, ITEMID, QUANTITY) VALUES (?,?,?,?)";
        Connection conn = null;
        PreparedStatement orderStatement = null;
        PreparedStatement orderItemStatement = null;
        ResultSet generatedKeys = null;
        try {
            conn = CONN.getConnection();
            conn.setAutoCommit(false);

            orderStatement = conn.prepareStatement(insertOrderQuery, Statement.RETURN_GENERATED_KEYS);
            orderStatement.setInt(1, orderId);
            orderStatement.setInt(2, guestId);
            orderStatement.setDate(3, new java.sql.Date(orderDate.getTime()));
            orderStatement.setString(4, orderStatus);
            int affectedRows = orderStatement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating order failed, no rows affected.");
            }
            generatedKeys = orderStatement.getGeneratedKeys();
            int orderId;
            if (generatedKeys.next()) {
                orderId = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }

            orderItemStatement = conn.prepareStatement(insertOrderItemQuery);
            for (ORDERITEM orderItem : orderItems) {
                orderItemStatement.setInt(1, orderId);
                orderItemStatement.setInt(2, orderItem.getItemId());
                orderItemStatement.setInt(3, orderItem.getQuantity());
                orderItemStatement.addBatch();
            }
            orderItemStatement.executeBatch();
            conn.commit();

            return new ORDER(orderId, guestId, orderDate, orderStatus);
        } catch (SQLException e) {
            if (conn != null) {
                conn.rollback();
            }
            throw e;
        } finally {
            if (generatedKeys != null) {
                generatedKeys.close();
            }
            if (orderStatement != null) {
                orderStatement.close();
            }
            if (orderItemStatement != null) {
                orderItemStatement.close();
            }
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    public static ORDER getOrderById(int orderId) throws SQLException {
        String selectQuery = "SELECT * FROM ORDERS WHERE ORDERID = ?";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement = conn.prepareStatement(selectQuery)) {
            statement.setInt(1, orderId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    int guestId = resultSet.getInt("GUEST_ID");
                    Date orderDate = resultSet.getDate("ORDERDATE");
                    String orderStatus = resultSet.getString("STATUS");
                    return new ORDER(orderId, guestId, orderDate, orderStatus);
                }
            }
        }
        return null;
    }
    public void updateOrder() throws SQLException {
        String updateQuery = "UPDATE ORDERS SET GUEST_ID = ?, ORDERDATE = ?, STATUS = ? WHERE ORDERID = ?";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement = conn.prepareStatement(updateQuery)) {
            statement.setInt(1, this.guestId);
            statement.setDate(2, new java.sql.Date(this.orderDate.getTime()));
            statement.setString(3, this.orderstatus);
            statement.setInt(4, this.orderId);
            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Updating order failed, no rows affected.");
            }
        }
    }
    public void deleteOrder() throws SQLException {
        String deleteItemsQuery = "DELETE FROM ORDER_ITEMS WHERE ORDERID = ?";
        String deleteOrderQuery = "DELETE FROM ORDERS WHERE ORDERID = ?";
        try (Connection conn = CONN.getConnection();
             PreparedStatement statement1 = conn.prepareStatement(deleteItemsQuery);
             PreparedStatement statement2 = conn.prepareStatement(deleteOrderQuery)) {
            statement1.setInt(1, this.orderId);
            statement1.executeUpdate();
            statement2.setInt(1, this.orderId);
            int affectedRows = statement2.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Deleting order failed, no rows affected.");
            }
        }
    }
    public void addOrderItem(ORDERITEM orderItem) {
        this.orderItems.add(orderItem);
    }

    public void removeOrderItem(ORDERITEM orderItem) {
        this.orderItems.remove(orderItem);
    }
}
