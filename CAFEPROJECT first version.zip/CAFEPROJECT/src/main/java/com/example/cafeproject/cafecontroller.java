package com.example.cafeproject;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class cafecontroller {
    @FXML
    private ListView<String> menuListView;

    @FXML
    private ListView<String> orderListView;

    private ObservableList<String> menuItems;
    private ObservableList<String> orderItems;

    public void initialize() {
        // Initialize menu items (you can replace this with actual menu items)
        menuItems = FXCollections.observableArrayList("Coffee", "Tea", "Sandwich", "Cake");
        menuListView.setItems(menuItems);

        // Initialize order items
        orderItems = FXCollections.observableArrayList();
        orderListView.setItems(orderItems);
    }

    @FXML
    public void addItemToOrder(ActionEvent event) {
        // Get selected item from menu
        String selectedItem = menuListView.getSelectionModel().getSelectedItem();
        if (selectedItem != null) {
            // Add selected item to order basket
            orderItems.add(selectedItem);
        }
    }
}

