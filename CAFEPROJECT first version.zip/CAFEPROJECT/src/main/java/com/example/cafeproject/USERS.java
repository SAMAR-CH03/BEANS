package com.example.cafeproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class USERS {
    private int userId;
    private String username;
    private String password;
    private String userType;
    private String favouriteColor;

    public USERS() {
    }

    public USERS(int userId, String username, String password, String userType, String favouriteColor) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.userType = userType;
        this.favouriteColor = favouriteColor;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public String getFavouriteColor() {
        return favouriteColor;
    }

    public void setFavouriteColor(String favouriteColor) {
        this.favouriteColor = favouriteColor;
    }

    public boolean login(String username, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM Users WHERE username = ? AND password = ? ");
            stmt.setString(1, username);
            stmt.setString(2, password);
            rs = stmt.executeQuery();
            if (rs.next()) {
                this.userId = rs.getInt("userId");
                this.username = rs.getString("username");
                this.password = rs.getString("password");
                this.userType = rs.getString("userType");
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean login2(String username, String favouriteColor, String userType) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM Users WHERE username = ? AND favouritecolor = ? AND usertype = ?");
            stmt.setString(1, username);
            stmt.setString(2, favouriteColor);
            stmt.setString(3, userType);
            rs = stmt.executeQuery();
            if (rs.next()) {
                this.userId = rs.getInt("userId");
                this.username = rs.getString("username");
                this.favouriteColor = rs.getString("favouritecolor");
                this.userType = rs.getString("userType");
                return true;
            } else {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void addUser(Integer userId, String username, String password, String userType, String favouriteColor) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("INSERT INTO Users (userid, username, password, usertype, favouritecolor) VALUES (?, ?, ?, ?,?)");
            stmt.setInt(1, userId);
            stmt.setString(2, username);
            stmt.setString(3, password);
            stmt.setString(4, userType);
            stmt.setString(5, favouriteColor);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("A new user was inserted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateUser(String username, String password, String userType, String favouriteColor) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("UPDATE Users SET password = ?, usertype = ?, favouritecolor = ? WHERE username = ?");
            stmt.setString(1, password);
            stmt.setString(2, userType);
            stmt.setString(3, favouriteColor);
            stmt.setString(4, username);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User was updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void deleteUser(String username, String password, String userType) {
        Connection conn = null;
        PreparedStatement stmt = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("DELETE FROM Users WHERE username = ?");
            stmt.setString(1, username);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("User was deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public String searchUserByUsername(String username) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT password FROM Users WHERE username = ?");
            stmt.setString(1, username);
            rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public static List<USERS> getAllUsers() {
        List<USERS> userList = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            conn = CONN.getConnection();
            stmt = conn.prepareStatement("SELECT * FROM Users");
            rs = stmt.executeQuery();
            while (rs.next()) {
                int userId = rs.getInt("userId");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String userType = rs.getString("userType");
                String favouriteColor = rs.getString("favouriteColor");
                USERS user = new USERS(userId, username, password, userType, favouriteColor);
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return userList;
    }
}



